See the [resources] folder for notes and usage example
