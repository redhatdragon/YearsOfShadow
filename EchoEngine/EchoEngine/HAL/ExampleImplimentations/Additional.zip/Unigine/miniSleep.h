#pragma once

void miniSleep(float milliseconds);